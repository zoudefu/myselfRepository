package com.mypro.model.interfaces;
/**
 * �����¼�
 * @author Xiloerfan
 *
 */
public interface OnClickListener {
	public void onClick();
}
